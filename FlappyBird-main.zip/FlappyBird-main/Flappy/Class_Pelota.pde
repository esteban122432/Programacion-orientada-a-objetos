class Pelota {
  PVector pos;
  PVector vel;
  PVector acc;
  float tamano = 30;

  Pelota(float x, float y) {
    pos = new PVector(x, y);
    vel = new PVector(0, 0);
    acc = new PVector(0, 0);
  }

  void addFuerza(PVector fuerza) {
    acc.add(fuerza);
  }

  void saltar() {
    vel.y = -8;
  }

  void mover() {
    vel.add(acc);
    pos.add(vel);
    acc.mult(0);
   
   

    if (pos.y < tamano/2) {
      pos.y = tamano/2;
      vel.y = 0;
    }
  }

  void mostrar() {
    fill(255, 255, 0);
    noStroke();
    ellipse(pos.x, pos.y, tamano, tamano);
  }
}
