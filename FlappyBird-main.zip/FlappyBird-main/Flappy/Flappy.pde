ArrayList<Cuadrado> tubos;
Pelota bird;
float ultimoPar = 0;
PVector G = new PVector(0, 0.4);

void setup() {
  size(800, 600);
  tubos = new ArrayList<Cuadrado>();
  bird = new Pelota(100, height / 2);
}

void draw() {
  background(150);
 
  Agregartubos();
  bird.addFuerza(G);
  bird.mover();
  borrartubos();
 
  for (Cuadrado t : tubos) {
    t.mover();
    t.mostrar();
  }
 
  bird.mostrar();
}

void keyPressed() {
  if (key == ' ') {
    bird.saltar();
  }
}

void borrartubos() {
  for (int i = tubos.size() - 1; i >= 0; i--) {
    Cuadrado Aux = tubos.get(i);
    if (Aux.pos.x + Aux.ancho < 0) {
      tubos.remove(i);
    }
  }
}

void Agregartubos() {
  float tActual = millis();
  float dt = tActual - ultimoPar;
 
  if (dt > 2500) {
    float gap = 140;
    float altoTop = random(50, height - gap - 50);
    float altoBottom = height - altoTop - gap;
   
    tubos.add(new Cuadrado(width, 0, 60, altoTop));
    tubos.add(new Cuadrado(width, height - altoBottom, 60, altoBottom));
    ultimoPar = tActual;
  }
}
