class Cuadrado {
  PVector pos;
  float ancho,largo ;
  float vel = 3;

  Cuadrado(float x, float y, float w, float h) {
    pos = new PVector(x, y);
    ancho = w;
    largo = h;
  }

  void mover() {
    pos.x -= vel;
  }

  void mostrar() {
    fill(0, 200, 100);
    stroke(255);
    rect(pos.x, pos.y, ancho, largo);
  }
}
